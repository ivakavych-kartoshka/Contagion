# Model Bedrock gọi được bằng API key hiện tại

Region kiểm: **us-east-1** · thời điểm: 2026-09-12 08:57

## ✅ GỌI ĐƯỢC (39)

- `deepseek.v3.2` → trả lời: 'OK'
- `google.gemma-3-27b-it` → trả lời: 'OK.'
- `google.gemma-3-4b-it` → trả lời: 'OK'
- `minimax.minimax-m2` → trả lời: ''
- `minimax.minimax-m2.1` → trả lời: ''
- `minimax.minimax-m2.5` → trả lời: ''
- `mistral.devstral-2-123b` → trả lời: 'OK'
- `mistral.magistral-small-2509` → trả lời: 'OK'
- `mistral.ministral-3-14b-instruct` → trả lời: 'OK'
- `mistral.ministral-3-3b-instruct` → trả lời: 'OK'
- `mistral.ministral-3-8b-instruct` → trả lời: 'OK'
- `mistral.mistral-large-3-675b-instruct` → trả lời: 'OK'
- `mistral.voxtral-mini-3b-2507` → trả lời: 'OK'
- `mistral.voxtral-small-24b-2507` → trả lời: 'OK'
- `moonshot.kimi-k2-thinking` → trả lời: ''
- `nvidia.nemotron-nano-12b-v2` → trả lời: 'OK'
- `nvidia.nemotron-nano-3-30b` → trả lời: 'OK'
- `nvidia.nemotron-nano-9b-v2` → trả lời: 'Okay, the user wants'
- `nvidia.nemotron-super-3-120b` → trả lời: 'OK'
- `openai.gpt-oss-120b-1:0` → trả lời: ''
- `openai.gpt-oss-20b-1:0` → trả lời: ''
- `openai.gpt-oss-safeguard-120b` → trả lời: ''
- `openai.gpt-oss-safeguard-20b` → trả lời: ''
- `qwen.qwen3-32b-v1:0` → trả lời: 'OK'
- `qwen.qwen3-coder-30b-a3b-v1:0` → trả lời: 'OK'
- `qwen.qwen3-coder-next` → trả lời: 'OK'
- `qwen.qwen3-next-80b-a3b` → trả lời: 'OK'
- `qwen.qwen3-vl-235b-a22b` → trả lời: 'OK'
- `us.anthropic.claude-haiku-4-5-20251001-v1:0` → trả lời: 'OK'
- `us.anthropic.claude-opus-4-5-20251101-v1:0` → trả lời: 'OK'
- `us.anthropic.claude-opus-4-6-v1` → trả lời: 'OK'
- `us.anthropic.claude-sonnet-4-5-20250929-v1:0` → trả lời: 'OK'
- `us.anthropic.claude-sonnet-4-6` → trả lời: 'OK'
- `us.deepseek.r1-v1:0` → trả lời: ''
- `us.meta.llama4-maverick-17b-instruct-v1:0` → trả lời: 'OK'
- `us.meta.llama4-scout-17b-instruct-v1:0` → trả lời: 'OK'
- `zai.glm-4.7` → trả lời: 'OK'
- `zai.glm-4.7-flash` → trả lời: 'OK'
- `zai.glm-5` → trả lời: 'OK'

## ⛔ Không có quyền / không tồn tại (6)

- `anthropic.claude-opus-4-20250514-v1:0`
- `us.anthropic.claude-3-5-haiku-20241022-v1:0`
- `us.anthropic.claude-3-5-sonnet-20241022-v2:0`
- `us.anthropic.claude-3-7-sonnet-20250219-v1:0`
- `us.anthropic.claude-opus-4-1-20250805-v1:0`
- `us.anthropic.claude-opus-4-20250514-v1:0`

## ⚠️ ID không hợp lệ cho on-demand (48)

- `anthropic.claude-fable-5`
- `anthropic.claude-fable-5-1`
- `anthropic.claude-haiku-4-5`
- `anthropic.claude-haiku-4-5-20251001-v1:0`
- `anthropic.claude-opus-4-1-20250805-v1:0`
- `anthropic.claude-opus-4-5-20251101-v1:0`
- `anthropic.claude-opus-4-6-v1`
- `anthropic.claude-opus-4-7`
- `anthropic.claude-opus-4-8`
- `anthropic.claude-opus-5`
- `anthropic.claude-sonnet-4-5-20250929-v1:0`
- `anthropic.claude-sonnet-4-6`
- `anthropic.claude-sonnet-5`
- `deepseek.r1-v1:0`
- `deepseek.v3-v1:0`
- `eu.anthropic.claude-fable-5`
- `eu.anthropic.claude-haiku-4-5-20251001-v1:0`
- `eu.anthropic.claude-opus-4-5-20251101-v1:0`
- `eu.anthropic.claude-opus-4-6-v1`
- `eu.anthropic.claude-opus-4-7`
- `eu.anthropic.claude-opus-4-8`
- `eu.anthropic.claude-opus-5`
- `eu.anthropic.claude-sonnet-4-5-20250929-v1:0`
- `eu.anthropic.claude-sonnet-4-6`
- `eu.anthropic.claude-sonnet-5`
- `meta.llama3-1-70b-instruct-v1:0`
- `meta.llama3-1-8b-instruct-v1:0`
- `meta.llama3-3-70b-instruct-v1:0`
- `meta.llama4-maverick-17b-instruct-v1:0`
- `meta.llama4-scout-17b-instruct-v1:0`
- `mistral.pixtral-large-2502-v1:0`
- `openai.gpt-5.4`
- `openai.gpt-5.5`
- `openai.gpt-5.6-luna`
- `openai.gpt-5.6-sol`
- `openai.gpt-5.6-terra`
- `openai.gpt-oss-120b`
- `openai.gpt-oss-20b`
- `qwen.qwen3-235b-a22b-2507-v1:0`
- `qwen.qwen3-coder-480b-a35b-v1:0`
- `us.anthropic.claude-fable-5`
- `us.anthropic.claude-fable-5-1`
- `us.anthropic.claude-opus-4-7`
- `us.anthropic.claude-opus-4-8`
- `us.anthropic.claude-opus-5`
- `us.anthropic.claude-sonnet-5`
- `writer.palmyra-x4-v1:0`
- `writer.palmyra-x5-v1:0`

## ❓ Lỗi khác (15)

- `global.anthropic.claude-fable-5`
- `global.anthropic.claude-fable-5-1`
- `global.anthropic.claude-haiku-4-5-20251001-v1:0`
- `global.anthropic.claude-opus-4-5-20251101-v1:0`
- `global.anthropic.claude-opus-4-6-v1`
- `global.anthropic.claude-opus-4-7`
- `global.anthropic.claude-opus-4-8`
- `global.anthropic.claude-opus-5`
- `global.anthropic.claude-sonnet-4-5-20250929-v1:0`
- `global.anthropic.claude-sonnet-4-6`
- `global.anthropic.claude-sonnet-5`
- `global.openai.gpt-5.6-luna`
- `global.openai.gpt-5.6-sol`
- `global.openai.gpt-5.6-terra`
- `us.anthropic.claude-sonnet-4-20250514-v1:0`
