# Figure notes — nguồn dữ liệu & cảnh báo trung thực

- `fig1_framework.png` — schematic (không phải số liệu); vẽ theo docs/metric.md §1/§2/§7.
- `fig2_per_role_survival.png` — nguồn: `rerun_chain_n40/per_edge_raw.json` + `rerun_chain_paraphrase_n40/...`; tính lại từ field `compromised` của từng trial.
- `fig3_taskb_defenses.png` — nguồn: `task_b_nlarge/summary.json` (none, paraphrase) + `task_b_redact_nlarge/report.md` (redact, parse regex).
- `fig4_obfuscation_heatmap.png` — nguồn: `taskb_obfuscation/results.json` (qwen) + mọi `*/results.json` có key `obfuscation`. Ô `redact·split` về logic PHẢI bằng `none·split` (attack split không chứa literal marker) — chênh lệch giữa 2 ô đó là thước đo nhiễu. k/n và CI đầy đủ ở bảng trong paper (hình chỉ in rate để tránh đè chữ).
- `fig5_cross_model.png` — nguồn: `task_b_nlarge/summary.json` (qwen) + mọi `frontier_*/results.json`; model mới tự xuất hiện.
- `fig6_content_form.png` — nguồn: `content_form_*/results.json` (`scripts/content_form_probe.py`). Hai arm replay dùng CÙNG một harness nên chênh lệch chỉ do **hình thức nội dung**.
- `fig7_markov.png` — nguồn: field `markov_check` của từng cell. ⚠️ Các cell dùng artifact CỐ ĐỊNH có thể cho `∏sᵢ` sai lệch (xem E25/E26) — đọc kèm `experiments/results/isolation_validity/report.md`.
- `fig8_utility_tradeoff.png` — nguồn: mọi `utility_*/results.json`. Góc trên-trái = defense lý tưởng. ⚠️ M_t hiện là proxy 'final answer không nhiễm payload'.

## Kiểm tra đè chữ (tự động, vì agent không xem được ảnh)

- [fig5_cross_model] đè: tick:'DeepSeek\nV3.2'  ×  tick:'DeepSeek\nV3.2'  (~86 px²)
- [fig5_cross_model] đè: tick:'DeepSeek\nV3.2'  ×  tick:'DeepSeek\nV3.2'  (~86 px²)
- [fig5_cross_model] đè: tick:'DeepSeek\nV3.2'  ×  tick:'DeepSeek\nV3.2'  (~86 px²)
- [fig5_cross_model] đè: tick:'DeepSeek\nV3.2'  ×  tick:'Llama 3.3\n70B'  (~35 px²)
- [fig5_cross_model] đè: tick:'qwen2.5\n7B (local)'  ×  tick:'Claude\nSonnet 4.5'  (~35 px²)

Sinh bởi `scripts/make_figures.py` · thư mục: `E:\NCKH\Contagion\experiments\results\figures`