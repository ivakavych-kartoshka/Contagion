# Depth curve — bedrock · deepseek.v3.2

chain n=10 · natural trials=120 · per-edge=60 · temp=0.7 · **fresh-artefact** (bắt buộc cho claim compositional)

Mỗi node là MỘT mốc độ sâu. `P(C_i=1)` đo từ natural runs; `∏s^cách ly` là tích các `s` đo cách ly trên đường từ entry tới node đó.

| depth i | agent | s cách ly vào node | P(C_i=1) đo được | ∏s cách ly | sai số tương đối |
|---|---|---|---|---|---|
| 0 | `agent_0` | — | 1.000 [0.969, 1.000] | 1.0000 | **0.0%** |
| 1 | `agent_1` | 0.700 | 0.667 [0.578, 0.745] | 0.7000 | **5.0%** |
| 2 | `agent_2` | 0.750 | 0.500 [0.412, 0.588] | 0.5250 | **5.0%** |
| 3 | `agent_3` | 0.833 | 0.400 [0.317, 0.489] | 0.4375 | **9.4%** |
| 4 | `agent_4` | 0.833 | 0.275 [0.203, 0.361] | 0.3646 | **32.6%** |
| 5 | `agent_5` | 0.683 | 0.258 [0.188, 0.343] | 0.2491 | **3.6%** |
| 6 | `agent_6` | 0.750 | 0.167 [0.111, 0.243] | 0.1868 | **12.1%** |
| 7 | `agent_7` | 0.700 | 0.167 [0.111, 0.243] | 0.1308 | **21.5%** |
| 8 | `agent_8` | 0.833 | 0.125 [0.077, 0.196] | 0.1090 | **12.8%** |
| 9 | `agent_9` | 0.717 | 0.117 [0.071, 0.186] | 0.0781 | **33.0%** |

## Cách đọc

- **Cột cuối là claim trung tâm**: sai số tương đối của phép đo cách ly theo độ sâu. Kỳ vọng: tăng theo `i`.
- Ở độ sâu lớn, `P(C_i=1)` tiến về 0 và CI rất rộng ⇒ các điểm cuối **kém tin cậy**; phải đọc kèm CI, và cần `--trials` đủ lớn.
- Model đáng tin cho đường cong này là model có `s` trung bình cao (nếu `s̄ ≈ 0.7`, chuỗi 14 hop gần như tắt hẳn).
