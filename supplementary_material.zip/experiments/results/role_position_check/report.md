# Kiểm soát role × vị trí (R2 W3/Q2) — 0 API

- lần A (mặc định): `role_base_qwen5` · model `qwen2.5:7b` · thứ tự role ['planner', 'worker', 'reviewer', 'aggregator', 'planner'] · 40 natural runs
- lần B (hoán vị): `role_perm_qwen5` · model `qwen2.5:7b` · thứ tự role ['reviewer', 'worker', 'planner', 'aggregator', 'planner'] · 40 natural runs

## Survival theo từng cạnh

| cạnh (vị trí) | node nhận | role ở A | s^nat (A) | role ở B | s^nat (B) |
|---|---|---|---|---|---|
| sâu 1 | `agent_1` | worker | 0.425 | worker | 0.525 |
| sâu 2 | `agent_2` | reviewer | 0.882 | planner | 0.381 |
| sâu 3 | `agent_3` | aggregator | 1.000 | aggregator | 1.000 |
| sâu 4 | `agent_4` | planner | 0.733 | planner | 0.875 |

## Hai cách đọc

Mỗi cách đọc dùng hết các cặp hợp lệ của nó (vị trí: **4** cặp; role: **3** cặp). Không cắt cho bằng nhau — cắt bớt sẽ vứt đi cặp chênh lớn nhất và có thể đảo kết luận.

| cách đọc | ý nghĩa | số cặp | khoảng cách tuyệt đối trung bình |
|---|---|---|---|
| **theo VỊ TRÍ** | cạnh sâu thứ k ở A ↔ cạnh sâu thứ k ở B | 4 | **0.186** |
| **theo ROLE** | role R ở A ↔ cùng role R ở B | 3 | **0.151** |

| role | s^nat ở A | s^nat ở B | |Δ| |
|---|---|---|---|
| worker | 0.425 | 0.525 | 0.100 |
| aggregator | 1.000 | 1.000 | 0.000 |
| planner | 0.733 | 0.381 | 0.352 |

## Kết luận

- Hai cách đọc **gần như bằng nhau** (0.186 vs 0.151, chênh 0.035 < ngưỡng 0.05) ⇒ **một hoán vị không tách được role khỏi vị trí**. Nói cách khác: không có bằng chứng rằng survival đi theo role *thay vì* theo độ sâu. Hệ quả cho bài: claim "role-dependent" phải hạ xuống "role và vị trí bị confound trong thiết kế này, và profile báo cáo là theo cách gán role cố định".

- Mức độ dịch chuyển của profile khi đổi thứ tự role (đọc theo vị trí): 0.186 điểm survival trung bình trên 4 cặp — tức profile **có xáo trộn** khi đổi nhãn, không bất biến.

> ⚠️ **Giới hạn:** đây là **một** hoán vị, không phải một họ hoán vị, nên là kiểm soát *định hướng* — không phải test thống kê và không có p-value. N với 3–6 cạnh cũng không đủ để ước lượng hiệu ứng role. Trong bài phải viết đúng mức này.
