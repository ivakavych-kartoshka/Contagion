# Kiểm soát role × vị trí (R2 W3/Q2) — 0 API

- lần A (mặc định): `role_base_us_meta_llama3_3_70b_instruct_v1_0` · model `us.meta.llama3-3-70b-instruct-v1:0` · thứ tự role ['planner', 'worker', 'reviewer', 'aggregator', 'planner'] · 40 natural runs
- lần B (hoán vị): `role_perm_us_meta_llama3_3_70b_instruct_v1_0` · model `us.meta.llama3-3-70b-instruct-v1:0` · thứ tự role ['reviewer', 'worker', 'planner', 'aggregator', 'aggregator'] · 40 natural runs

## Survival theo từng cạnh

| cạnh (vị trí) | node nhận | role ở A | s^nat (A) | role ở B | s^nat (B) |
|---|---|---|---|---|---|
| sâu 1 | `agent_1` | planner | 1.000 | worker | 1.000 |
| sâu 2 | `agent_2` | worker | 0.825 | planner | 0.700 |
| sâu 3 | `agent_3` | reviewer | 0.970 | aggregator | 1.000 |
| sâu 4 | `agent_4` | aggregator | 0.688 | aggregator | 0.929 |

## Hai cách đọc

Mỗi cách đọc dùng hết các cặp hợp lệ của nó (vị trí: **4** cặp; role: **3** cặp). Không cắt cho bằng nhau — cắt bớt sẽ vứt đi cặp chênh lớn nhất và có thể đảo kết luận.

| cách đọc | ý nghĩa | số cặp | khoảng cách tuyệt đối trung bình |
|---|---|---|---|
| **theo VỊ TRÍ** | cạnh sâu thứ k ở A ↔ cạnh sâu thứ k ở B | 4 | **0.099** |
| **theo ROLE** | role R ở A ↔ cùng role R ở B | 3 | **0.263** |

| role | s^nat ở A | s^nat ở B | |Δ| |
|---|---|---|---|
| planner | 1.000 | 0.700 | 0.300 |
| worker | 0.825 | 1.000 | 0.175 |
| aggregator | 0.688 | 1.000 | 0.312 |

## Kết luận

- Khoảng cách theo **VỊ TRÍ nhỏ hơn** (0.099 vs 0.263, chênh 0.163) ⇒ survival đi theo *vị trí* nhiều hơn: role chỉ là nhãn, độ sâu mới là biến giải thích. Khi đó phải HẠ claim "role-dependent" xuống "position-dependent" trong bài.

- Mức độ dịch chuyển của profile khi đổi thứ tự role (đọc theo vị trí): 0.099 điểm survival trung bình trên 4 cặp — tức profile **có xáo trộn** khi đổi nhãn, không bất biến.

> ⚠️ **Giới hạn:** đây là **một** hoán vị, không phải một họ hoán vị, nên là kiểm soát *định hướng* — không phải test thống kê và không có p-value. N với 3–6 cạnh cũng không đủ để ước lượng hiệu ứng role. Trong bài phải viết đúng mức này.
