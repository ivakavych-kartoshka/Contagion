# Kiểm soát role × vị trí (R2 W3/Q2) — 0 API

- lần A (mặc định): `role_base_us_meta_llama3_3_70b_instruct_v1_0` · model `us.meta.llama3-3-70b-instruct-v1:0` · thứ tự role ['planner', 'worker', 'reviewer', 'aggregator', 'planner'] · 40 natural runs
- lần B (hoán vị): `role_perm_us_meta_llama3_3_70b_instruct_v1_0` · model `us.meta.llama3-3-70b-instruct-v1:0` · thứ tự role ['reviewer', 'worker', 'planner', 'aggregator', 'aggregator'] · 40 natural runs

## Survival theo từng cạnh

| cạnh (vị trí) | node nhận | role ở A | s^nat (A) | role ở B | s^nat (B) |
|---|---|---|---|---|---|
| sâu 1 | `agent_1` | worker | 1.000 | worker | 1.000 |
| sâu 2 | `agent_2` | reviewer | 0.975 | planner | 0.575 |
| sâu 3 | `agent_3` | aggregator | 1.000 | aggregator | 1.000 |
| sâu 4 | `agent_4` | planner | 0.692 | aggregator | 0.957 |

## Hai cách đọc

Mỗi cách đọc dùng hết các cặp hợp lệ của nó (vị trí: **4** cặp; role: **3** cặp). Không cắt cho bằng nhau — cắt bớt sẽ vứt đi cặp chênh lớn nhất và có thể đảo kết luận.

| cách đọc | ý nghĩa | số cặp | khoảng cách tuyệt đối trung bình |
|---|---|---|---|
| **theo VỊ TRÍ** | cạnh sâu thứ k ở A ↔ cạnh sâu thứ k ở B | 4 | **0.166** |
| **theo ROLE** | role R ở A ↔ cùng role R ở B | 3 | **0.039** |

| role | s^nat ở A | s^nat ở B | |Δ| |
|---|---|---|---|
| worker | 1.000 | 1.000 | 0.000 |
| aggregator | 1.000 | 1.000 | 0.000 |
| planner | 0.692 | 0.575 | 0.117 |

## Kết luận

- Khoảng cách theo **ROLE nhỏ hơn** (0.039 vs 0.166, chênh 0.127) ⇒ survival đi theo *role* nhiều hơn theo *vị trí*: profile gần như giữ nguyên khi đổi thứ tự role. Ủng hộ "role-dependent".

- Mức độ dịch chuyển của profile khi đổi thứ tự role (đọc theo vị trí): 0.166 điểm survival trung bình trên 4 cặp — tức profile **có xáo trộn** khi đổi nhãn, không bất biến.

> ⚠️ **Giới hạn:** đây là **một** hoán vị, không phải một họ hoán vị, nên là kiểm soát *định hướng* — không phải test thống kê và không có p-value. N với 3–6 cạnh cũng không đủ để ước lượng hiệu ứng role. Trong bài phải viết đúng mức này.
