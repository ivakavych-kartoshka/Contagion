# Vòng 2 — bài khó hơn (off-by-one, tie-break, BFS)

Region us-east-1. Tổng 18 test ẩn.

| Model | Nhận `temperature`? | Điểm | Chi tiết |
|---|---|---|---|
| `us.anthropic.claude-opus-4-6-v1` | có | **18/18** | min_rooms 7/7 · top_k_frequent 5/5 · bfs_grid 6/6 |
| `us.anthropic.claude-opus-4-8` | **không** | **18/18** | min_rooms 7/7 · top_k_frequent 5/5 · bfs_grid 6/6 |
| `us.anthropic.claude-sonnet-4-6` | có | **18/18** | min_rooms 7/7 · top_k_frequent 5/5 · bfs_grid 6/6 |
| `us.anthropic.claude-sonnet-5` | **không** | **18/18** | min_rooms 7/7 · top_k_frequent 5/5 · bfs_grid 6/6 |
| `qwen.qwen3-coder-next` | có | **18/18** | min_rooms 7/7 · top_k_frequent 5/5 · bfs_grid 6/6 |
| `deepseek.v3.2` | có | **18/18** | min_rooms 7/7 · top_k_frequent 5/5 · bfs_grid 6/6 |
| `zai.glm-5` | có | **18/18** | min_rooms 7/7 · top_k_frequent 5/5 · bfs_grid 6/6 |
