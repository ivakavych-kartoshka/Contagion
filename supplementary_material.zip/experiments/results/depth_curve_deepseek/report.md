# Depth curve — bedrock · deepseek.v3.2

chain n=8 · natural trials=60 · per-edge=30 · temp=0.7 · **fresh-artefact** (bắt buộc cho claim compositional)

Mỗi node là MỘT mốc độ sâu. `P(C_i=1)` đo từ natural runs; `∏s^cách ly` là tích các `s` đo cách ly trên đường từ entry tới node đó.

| depth i | agent | s cách ly vào node | P(C_i=1) đo được | ∏s cách ly | sai số tương đối |
|---|---|---|---|---|---|
| 0 | `agent_0` | — | 1.000 [0.940, 1.000] | 1.0000 | **0.0%** |
| 1 | `agent_1` | 0.800 | 0.683 [0.558, 0.787] | 0.8000 | **17.1%** |
| 2 | `agent_2` | 0.900 | 0.533 [0.409, 0.654] | 0.7200 | **35.0%** |
| 3 | `agent_3` | 0.667 | 0.450 [0.331, 0.575] | 0.4800 | **6.7%** |
| 4 | `agent_4` | 0.900 | 0.333 [0.227, 0.459] | 0.4320 | **29.6%** |
| 5 | `agent_5` | 0.567 | 0.283 [0.185, 0.408] | 0.2448 | **13.6%** |
| 6 | `agent_6` | 0.733 | 0.200 [0.118, 0.318] | 0.1795 | **10.2%** |
| 7 | `agent_7` | 0.633 | 0.167 [0.093, 0.280] | 0.1137 | **31.8%** |

## Cách đọc

- **Cột cuối là claim trung tâm**: sai số tương đối của phép đo cách ly theo độ sâu. Kỳ vọng: tăng theo `i`.
- Ở độ sâu lớn, `P(C_i=1)` tiến về 0 và CI rất rộng ⇒ các điểm cuối **kém tin cậy**; phải đọc kèm CI, và cần `--trials` đủ lớn.
- Model đáng tin cho đường cong này là model có `s` trung bình cao (nếu `s̄ ≈ 0.7`, chuỗi 14 hop gần như tắt hẳn).
