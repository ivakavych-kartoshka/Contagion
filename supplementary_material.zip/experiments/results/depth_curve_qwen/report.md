# Depth curve — openai · qwen2.5:7b

chain n=7 · natural trials=60 · per-edge=25 · temp=0.7 · **fresh-artefact** (bắt buộc cho claim compositional)

Mỗi node là MỘT mốc độ sâu. `P(C_i=1)` đo từ natural runs; `∏s^cách ly` là tích các `s` đo cách ly trên đường từ entry tới node đó.

| depth i | agent | s cách ly vào node | P(C_i=1) đo được | ∏s cách ly | sai số tương đối |
|---|---|---|---|---|---|
| 0 | `agent_0` | — | 1.000 [0.940, 1.000] | 1.0000 | **0.0%** |
| 1 | `agent_1` | 0.320 | 0.467 [0.346, 0.591] | 0.3200 | **31.4%** |
| 2 | `agent_2` | 0.680 | 0.417 [0.301, 0.543] | 0.2176 | **47.8%** |
| 3 | `agent_3` | 0.600 | 0.400 [0.286, 0.526] | 0.1306 | **67.4%** |
| 4 | `agent_4` | 0.640 | 0.283 [0.185, 0.408] | 0.0836 | **70.5%** |
| 5 | `agent_5` | 0.320 | 0.233 [0.144, 0.354] | 0.0267 | **88.5%** |
| 6 | `agent_6` | 0.880 | 0.217 [0.131, 0.336] | 0.0235 | **89.1%** |

## Cách đọc

- **Cột cuối là claim trung tâm**: sai số tương đối của phép đo cách ly theo độ sâu. Kỳ vọng: tăng theo `i`.
- Ở độ sâu lớn, `P(C_i=1)` tiến về 0 và CI rất rộng ⇒ các điểm cuối **kém tin cậy**; phải đọc kèm CI, và cần `--trials` đủ lớn.
- Model đáng tin cho đường cong này là model có `s` trung bình cao (nếu `s̄ ≈ 0.7`, chuỗi 14 hop gần như tắt hẳn).
