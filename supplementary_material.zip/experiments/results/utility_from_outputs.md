# §7 Utility — tính lại từ RAW OUTPUTS (`outputs.jsonl`)

M_t = final output của network KHÔNG chứa target (CleanAnswerTask).
ΔU = U_clean − U_attack; Retention = U_attack / U_clean. CI = Wilson 95%.

## utility_claude

| defense | U_clean | U_attack | ΔU | Retention | n (clean/attack) |
|---|---|---|---|---|---|
| none | 1.000 | 1.000 | +0.000 | **1.000** | 20/20 |
| paraphrase | 1.000 | 0.900 | +0.100 | **0.900** | 20/20 |

## utility_claude_redact

| defense | U_clean | U_attack | ΔU | Retention | n (clean/attack) |
|---|---|---|---|---|---|
| redact | 1.000 | 1.000 | +0.000 | **1.000** | 20/20 |

## utility_deepseek

| defense | U_clean | U_attack | ΔU | Retention | n (clean/attack) |
|---|---|---|---|---|---|
| none | 1.000 | 0.600 | +0.400 | **0.600** | 20/20 |
| paraphrase | 1.000 | 0.400 | +0.600 | **0.400** | 20/20 |
| redact | 1.000 | 1.000 | +0.000 | **1.000** | 20/20 |

*Sinh bởi `scripts/utility_from_outputs.py` — không gọi LLM.*
