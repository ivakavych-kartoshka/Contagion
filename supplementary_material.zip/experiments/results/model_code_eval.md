# Chọn model sinh code — đo bằng bài có test ẩn

Region us-east-1. Mỗi model làm 3 bài, tổng 19 test ẩn.

| Model | Nhận `temperature`? | Điểm | Chi tiết |
|---|---|---|---|
| `us.anthropic.claude-opus-4-6-v1` | có | **19/19** | merge_intervals 6/6 · balanced_brackets 7/7 · parse_pairs 6/6 |
| `us.anthropic.claude-sonnet-4-6` | có | **19/19** | merge_intervals 6/6 · balanced_brackets 7/7 · parse_pairs 6/6 |
| `us.anthropic.claude-opus-4-8` | **không** | **19/19** | merge_intervals 6/6 · balanced_brackets 7/7 · parse_pairs 6/6 |
| `us.anthropic.claude-sonnet-5` | **không** | **19/19** | merge_intervals 6/6 · balanced_brackets 7/7 · parse_pairs 6/6 |
| `us.anthropic.claude-sonnet-4-5-20250929-v1:0` | có | **19/19** | merge_intervals 6/6 · balanced_brackets 7/7 · parse_pairs 6/6 |
| `qwen.qwen3-coder-next` | có | **19/19** | merge_intervals 6/6 · balanced_brackets 7/7 · parse_pairs 6/6 |
| `deepseek.v3.2` | có | **19/19** | merge_intervals 6/6 · balanced_brackets 7/7 · parse_pairs 6/6 |
| `zai.glm-5` | có | **19/19** | merge_intervals 6/6 · balanced_brackets 7/7 · parse_pairs 6/6 |
| `us.anthropic.claude-opus-5` | **không** | **13/19** | merge_intervals 6/6 · balanced_brackets 7/7 · parse_pairs 0/6 |

## Đề bài

### merge_intervals
Write a Python function `merge_intervals(intervals)` that takes a list of [start, end] pairs and returns a new list of non-overlapping intervals merged, sorted by start. Touching intervals ([1,2],[2,3]) must merge. Return ONLY the code, no explanation.
- cơ bản
- chạm nhau
- rỗng
- lồng nhau
- chưa sắp xếp
- điểm rời

### balanced_brackets
Write a Python function `balanced(s)` that returns True if the brackets in string s are correctly balanced and nested, considering (), [] and {}. Any other characters are ignored. Return ONLY the code, no explanation.
- đơn giản
- lồng đúng
- sai thứ tự
- thiếu đóng
- bỏ qua ký tự khác
- rỗng
- đóng thừa

### parse_pairs
Write a Python function `parse_pairs(s)` that parses a string like 'a=1;b=2' into a dict. Rules: split on ';', ignore empty pieces, ignore pieces without '=', keep the LAST value when a key repeats, strip whitespace from keys and values. Return ONLY the code.
- cơ bản
- bỏ phần rỗng
- bỏ phần không có =
- khoá lặp lấy cuối
- strip
- giá trị có =

