# Permutation p-value + bootstrap CI cho depth slope (0 API)

10000 hoán vị (Monte Carlo khi n > 9) · 10000 bootstrap · seed 7. p hai phía cho Spearman; CI 95% percentile.

| model | lần chạy | điểm | bỏ | sâu nhất | rho | CI95 rho | p (perm) | slope (pp/hop) | CI95 slope |
|---|---|---|---|---|---|---|---|---|---|
| qwen2.5:7b | n=7 | 6 | 0 | 6 | +1.00 | [1.0, 1.0] | 0.0028 (exact) | +11.8 | [7.827, 14.805] |
| us.meta.llama3-3-70b-instruct-v1:0 | n=15 | 10 | 4 | 10 | +0.77 | [0.304, 0.948] | 0.0136 (monte-carlo) | +6.8 | [2.72, 11.367] |
| us.meta.llama3-3-70b-instruct-v1:0 | n=15 | 10 | 4 | 10 | +0.76 | [0.296, 0.938] | 0.0143 (monte-carlo) | +6.3 | [2.039, 10.995] |
| deepseek.v3.2 | n=8 | 7 | 0 | 7 | -0.07 | [-0.889, 0.882] | 0.9063 (exact) | +0.1 | [-5.337, 4.529] |
| deepseek.v3.2 | n=10 | 9 | 0 | 9 | +0.65 | [-0.07, 0.983] | 0.0666 (exact) | +2.3 | [-0.337, 4.002] |

## ⚠️ Cảnh báo

- depth_curve_qwen: chỉ 6 điểm — interval rộng, đọc như diagnostic chứ không phải test
- depth_curve_deepseek: chỉ 7 điểm — interval rộng, đọc như diagnostic chứ không phải test

## Câu LaTeX sẵn để dán vào §5.7

```latex
Across models the slopes span +0.1 to +11.8 points per hop; the rank correlation is significant where the chain is long enough to test it (qwen2.5:7b: $\rho = +1.00$, permutation $p = 0.003$, $n = 6$ depths) and indistinguishable from chance on the shortest profiles ([fill in from the table]). We report the profile as a diagnostic, not a calibrated correction: at these depths the bootstrap interval for the slope is wide, and a short low-power chain can read as flat.
```

## Cách đọc

1. `p (perm)` là kiểm định **hoán vị** cho Spearman — không giả định phân phối chuẩn, phù hợp vì n rất nhỏ.
2. **Cảnh báo quan trọng:** với n ≤ 9 điểm, ngay cả một `rho` hoàn hảo cũng chỉ đạt p ≈ 0.002–0.01 ở dạng hai phía; `p` KHÔNG chứng minh độ dốc ổn định. Đây là lý do phải viết "diagnostic, not a test".
3. CI bootstrap là **percentile**, tính trên các cặp (depth, err) — không hiệu chỉnh cho tương quan giữa các độ sâu của cùng một chuỗi.
