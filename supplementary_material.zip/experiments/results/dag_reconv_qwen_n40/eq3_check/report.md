# Eq. (3) trên DAG reconvergent `s→u→{A,B}→t` — đối chiếu SỐ ĐO (0 API)

Nguồn: `summary.json` · 600 activation đã judge · 40 natural trial · 240 activation của target `agent_4`

## s theo từng cạnh

| edge | s^nat (trong chuỗi) | s^ctrl (cách ly) | nat/ctrl |
|---|---|---|---|
| `agent_0->agent_1` | 0.375 | 0.400 | 0.94× |
| `agent_1->agent_2` | 0.933 | 0.933 | 1.00× |
| `agent_1->agent_3` | 0.800 | 0.367 | 2.18× |
| `agent_2->agent_4` | 1.000 | 0.533 | 1.88× |
| `agent_3->agent_4` | 1.000 | 0.933 | 1.07× |

## Ba cách tính P[target] vs số đo

| cách tính | giá trị | lệch so với số đo |
|---|---|---|
| **ASR đo được (natural runs)** | **0.792** [0.7359, 0.8383] (n=240) | mốc |
| Eq. (1) tích chuỗi (∏s^nat) | 0.280 | công thức chain — sai cấu trúc ở đây (2 path) |
| Eq. (3) từ s^nat | 0.545 | +0.247 |
| Eq. (3) từ s^ctrl (đo cách ly) | 0.309 | +0.483 |
| mô hình shared-ancestor (tham chiếu) | 0.280 | Pr[A∧B] = s_uA·s_uB·p_u |

## Tự kiểm tra harness (ở target)

- s^natural = 0.792 · s^replay(in-context) = 0.717 (43/60) · Δ = -0.075 → **PASS**

## Kết luận (đọc theo thứ tự này)

- **Eq. (3) từ s^nat LỆCH số đo** (Δ = +0.247) ⇒ có correlation thật giữa hai nhánh, hoặc harness replay sai — đọc self-check trước.
- **Eq. (3) từ s^ctrl LỆCH số đo** (Δ = +0.483) ⇒ phép đo cách ly **không transport** trên topology reconvergent: dùng benchmark single-agent sẽ sai reachability. Đây là câu trả lời cho R1 Q2, và nó tách khỏi câu hỏi shared-ancestor.

Sai số do transport ở cấp cạnh = tỉ lệ nat/ctrl trong bảng đầu; sai số do shared-ancestor (nếu có) = số đo − Eq. (3) từ s^nat.
