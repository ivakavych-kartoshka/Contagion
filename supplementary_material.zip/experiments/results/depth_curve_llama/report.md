# Depth curve — bedrock · us.meta.llama3-3-70b-instruct-v1:0

chain n=15 · natural trials=60 · per-edge=30 · temp=0.7 · **fresh-artefact** (bắt buộc cho claim compositional)

Mỗi node là MỘT mốc độ sâu. `P(C_i=1)` đo từ natural runs; `∏s^cách ly` là tích các `s` đo cách ly trên đường từ entry tới node đó.

| depth i | agent | s cách ly vào node | P(C_i=1) đo được | ∏s cách ly | sai số tương đối |
|---|---|---|---|---|---|
| 0 | `agent_0` | — | 1.000 [0.940, 1.000] | 1.0000 | **0.0%** |
| 1 | `agent_1` | 1.000 | 1.000 [0.940, 1.000] | 1.0000 | **0.0%** |
| 2 | `agent_2` | 0.300 | 0.883 [0.778, 0.942] | 0.3000 | **66.0%** |
| 3 | `agent_3` | 1.000 | 0.867 [0.758, 0.931] | 0.3000 | **65.4%** |
| 4 | `agent_4` | 1.000 | 0.683 [0.558, 0.787] | 0.3000 | **56.1%** |
| 5 | `agent_5` | 1.000 | 0.633 [0.507, 0.744] | 0.3000 | **52.6%** |
| 6 | `agent_6` | 0.300 | 0.583 [0.457, 0.699] | 0.0900 | **84.6%** |
| 7 | `agent_7` | 1.000 | 0.583 [0.457, 0.699] | 0.0900 | **84.6%** |
| 8 | `agent_8` | 1.000 | 0.450 [0.331, 0.575] | 0.0900 | **80.0%** |
| 9 | `agent_9` | 1.000 | 0.433 [0.316, 0.559] | 0.0900 | **79.2%** |
| 10 | `agent_10` | 0.333 | 0.400 [0.286, 0.526] | 0.0300 | **92.5%** |
| 11 | `agent_11` | 1.000 | 0.000 [0.000, 0.060] | 0.0300 | **—** |
| 12 | `agent_12` | 1.000 | 0.000 [0.000, 0.060] | 0.0300 | **—** |
| 13 | `agent_13` | 1.000 | 0.000 [0.000, 0.060] | 0.0300 | **—** |
| 14 | `agent_14` | 0.233 | 0.000 [0.000, 0.060] | 0.0070 | **—** |

## Cách đọc

- **Cột cuối là claim trung tâm**: sai số tương đối của phép đo cách ly theo độ sâu. Kỳ vọng: tăng theo `i`.
- Ở độ sâu lớn, `P(C_i=1)` tiến về 0 và CI rất rộng ⇒ các điểm cuối **kém tin cậy**; phải đọc kèm CI, và cần `--trials` đủ lớn.
- Model đáng tin cho đường cong này là model có `s` trung bình cao (nếu `s̄ ≈ 0.7`, chuỗi 14 hop gần như tắt hẳn).
