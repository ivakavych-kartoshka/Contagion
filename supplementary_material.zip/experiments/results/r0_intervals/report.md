# CI cho R₀ — chỉ tính khi dữ liệu cho phép (0 API)

R₀ = Σ_e (nguồn truyền thành công) / Σ_e (nguồn bị compromise), suy từ `per_edge` và `survival_natural` của natural runs. Bootstrap theo cạnh, 10000 lần, seed 7.

## Dựng lại được đầy đủ (công thức khớp `r0` đã lưu)

| thư mục | model | topology | N | ASR [CI] | R₀ đã lưu | R₀ tính lại | CI95 R₀ |
|---|---|---|---|---|---|---|---|
| `topo_tree_n7` | llama3-3-70b-ins | tree | 40 | 0.800 [0.6524239261814333, 0.8950013502683314] | 0.831 | 0.821 | [0.6625, 0.9667] |
| `topo_tree_llama_n10` | llama3-3-70b-ins | tree | 40 | 0.650 [0.4950559699353739, 0.7786566682895086] | 0.882 | 0.864 | [0.7611, 0.9587] |

## ⚠️ Chỉ dựng lại được từ MỘT TẦM CON cạnh — không dùng làm CI

| thư mục | topology | cạnh dùng được | R₀ tính lại | R₀ đã lưu | lý do |
|---|---|---|---|---|---|
| `topo_star_nova_n7` | star | 1/6 | 0.000 | 0.0 | chỉ 1/6 cạnh có natural survival riêng → R₀ dựng lại được chỉ từ tập con này |

## ⛔ Tính lại lệch giá trị đã lưu — không in CI

- `topo_chain_n7`: tính lại 0.8836 vs đã lưu 0.8206
- `topo_star_n7`: tính lại 0.7250 vs đã lưu 0.4203 (chỉ 1/6 cạnh có natural survival riêng → R₀ dựng lại được chỉ từ tập con này)
- `topo_star_llama_n10`: tính lại 0.6750 vs đã lưu 0.4030 (chỉ 1/9 cạnh có natural survival riêng → R₀ dựng lại được chỉ từ tập con này)
- `topo_star_deepseek_n7`: tính lại 0.7500 vs đã lưu 0.4286 (chỉ 1/6 cạnh có natural survival riêng → R₀ dựng lại được chỉ từ tập con này)
- `topo_tree_deepseek_n7`: tính lại 0.6752 vs đã lưu 0.7436
- `topo_tree_nova_n7`: tính lại 0.3569 vs đã lưu 0.3939

## Hệ quả cho bài (đề xuất sửa §3.6)

§3.6 hiện hứa R₀ "with a Wilson interval". Có hai lựa chọn trung thực:

1. **Bỏ hứa hẹn** đó và nói rõ: R₀ là statistic mô tả, báo kèm ASR với interval; trên chain vẫn báo được interval bootstrap theo cạnh (ở trên).
2. Hoặc báo R₀ chỉ cho chain, và ghi rõ vì sao star/tree không có interval.

Không nên in interval cho star/tree từ dữ liệu này.
