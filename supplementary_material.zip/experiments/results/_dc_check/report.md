# Depth curve — mock · mock

chain n=8 · natural trials=40 · per-edge=25 · temp=0.7 · **fresh-artefact** (bắt buộc cho claim compositional)

Mỗi node là MỘT mốc độ sâu. `P(C_i=1)` đo từ natural runs; `∏s^cách ly` là tích các `s` đo cách ly trên đường từ entry tới node đó.

| depth i | agent | s cách ly vào node | P(C_i=1) đo được | ∏s cách ly | sai số tương đối |
|---|---|---|---|---|---|
| 0 | `agent_0` | — | 1.000 [0.912, 1.000] | 1.0000 | **0.0%** |
| 1 | `agent_1` | 1.000 | 1.000 [0.912, 1.000] | 1.0000 | **0.0%** |
| 2 | `agent_2` | 1.000 | 1.000 [0.912, 1.000] | 1.0000 | **0.0%** |
| 3 | `agent_3` | 1.000 | 1.000 [0.912, 1.000] | 1.0000 | **0.0%** |
| 4 | `agent_4` | 1.000 | 1.000 [0.912, 1.000] | 1.0000 | **0.0%** |
| 5 | `agent_5` | 1.000 | 1.000 [0.912, 1.000] | 1.0000 | **0.0%** |
| 6 | `agent_6` | 1.000 | 1.000 [0.912, 1.000] | 1.0000 | **0.0%** |
| 7 | `agent_7` | 1.000 | 1.000 [0.912, 1.000] | 1.0000 | **0.0%** |

## Cách đọc

- **Cột cuối là claim trung tâm**: sai số tương đối của phép đo cách ly theo độ sâu. Kỳ vọng: tăng theo `i`.
- Ở độ sâu lớn, `P(C_i=1)` tiến về 0 và CI rất rộng ⇒ các điểm cuối **kém tin cậy**; phải đọc kèm CI, và cần `--trials` đủ lớn.
- Model đáng tin cho đường cong này là model có `s` trung bình cao (nếu `s̄ ≈ 0.7`, chuỗi 14 hop gần như tắt hẳn).
