# Phase-2 — Synthetic Method Validation Report

## 1. Wilson 95% CI coverage (Binomial proportion, metric.md §1)

Target coverage = 0.95 (within MC error ≈ ±1.96·sqrt(0.95·0.05/N_rep)).

| p | n | n_rep | coverage | mean width |
|---|---|---|---|---|
| 0.05 | 10 | 2000 | 0.9165 | 0.3267 |
| 0.05 | 30 | 2000 | 0.9390 | 0.1727 |
| 0.05 | 100 | 2000 | 0.9635 | 0.0882 |
| 0.05 | 300 | 2000 | 0.9475 | 0.0499 |
| 0.1 | 10 | 2000 | 0.9305 | 0.3691 |
| 0.1 | 30 | 2000 | 0.9735 | 0.2144 |
| 0.1 | 100 | 2000 | 0.9280 | 0.1175 |
| 0.1 | 300 | 2000 | 0.9500 | 0.0679 |
| 0.2 | 10 | 2000 | 0.9645 | 0.4326 |
| 0.2 | 30 | 2000 | 0.9600 | 0.2716 |
| 0.2 | 100 | 2000 | 0.9315 | 0.1542 |
| 0.2 | 300 | 2000 | 0.9455 | 0.0899 |
| 0.5 | 10 | 2000 | 0.9750 | 0.5061 |
| 0.5 | 30 | 2000 | 0.9520 | 0.3317 |
| 0.5 | 100 | 2000 | 0.9345 | 0.1914 |
| 0.5 | 300 | 2000 | 0.9510 | 0.1123 |
| 0.8 | 10 | 2000 | 0.9645 | 0.4326 |
| 0.8 | 30 | 2000 | 0.9600 | 0.2716 |
| 0.8 | 100 | 2000 | 0.9315 | 0.1542 |
| 0.8 | 300 | 2000 | 0.9455 | 0.0899 |
| 0.9 | 10 | 2000 | 0.9305 | 0.3691 |
| 0.9 | 30 | 2000 | 0.9735 | 0.2144 |
| 0.9 | 100 | 2000 | 0.9280 | 0.1175 |
| 0.9 | 300 | 2000 | 0.9500 | 0.0679 |
| 0.95 | 10 | 2000 | 0.9165 | 0.3267 |
| 0.95 | 30 | 2000 | 0.9390 | 0.1727 |
| 0.95 | 100 | 2000 | 0.9635 | 0.0882 |
| 0.95 | 300 | 2000 | 0.9475 | 0.0499 |

## 2. Markov test SIZE (true first-order Markov data)

Verdict rule is CI-overlap based (conservative): reject rate should be small.

| n_agents | s | trials | per_edge | n_rep | consistent | ASR<prod (sub) | ASR>prod (super) | insufficient |
|---|---|---|---|---|---|---|---|---|
| 4 | 0.6 | 300 | 200 | 300 | 0.9900 | 0.0067 | 0.0033 | 0.0000 |
| 5 | 0.6 | 300 | 200 | 300 | 0.9967 | 0.0033 | 0.0000 | 0.0000 |
| 5 | 0.8 | 300 | 200 | 300 | 0.9933 | 0.0067 | 0.0000 | 0.0000 |

## 3. Markov test POWER (super-Markov latent-regime data)

Data: per-trial latent regime → ASR_true > prod(s_bar). Power = 'super' rate.

| n_agents | s_lo | s_hi | w_hi | s_bar | trials | per_edge | n_rep | super (power) | consistent |
|---|---|---|---|---|---|---|---|---|---|
| 5 | 0.4 | 0.9 | 0.5 | 0.650 | 100 | 100 | 300 | 0.6567 | 0.3433 |
| 5 | 0.4 | 0.9 | 0.5 | 0.650 | 200 | 200 | 300 | 0.9400 | 0.0600 |
| 5 | 0.4 | 0.9 | 0.5 | 0.650 | 300 | 200 | 300 | 0.9900 | 0.0100 |

## 3b. Kiểm định Markov HÌNH THỨC — hiệu chuẩn (markov_test_formal)

Dữ liệu Markov THẬT ⇒ size kỳ vọng ≈ alpha = 0.05; bias kỳ vọng ≈ 0.

| n_agents | s | true ASR | trials | per_edge | n_rep | mean Δ | bias (σ) | size | median p | mean MDE |
|---|---|---|---|---|---|---|---|---|---|---|
| 5 | 0.6 | 0.1296 | 120 | 120 | 60 | -0.0038 | -0.10 | 0.083 | 0.477 | 0.099 |
| 5 | 0.7 | 0.2401 | 400 | 400 | 60 | +0.0013 | +0.05 | 0.067 | 0.560 | 0.074 |
| 5 | 0.9 | 0.6561 | 400 | 400 | 60 | +0.0028 | +0.08 | 0.083 | 0.409 | 0.090 |

## 3c. Power: kiểm định hình thức vs quy tắc CI-chồng-nhau

Dữ liệu super-Markov (latent regime) ⇒ true ASR > ∏s̄ᵢ.

| n_agents | s_lo | s_hi | w_hi | s̄ | true ASR | ∏s̄ᵢ | trials | power (formal) | power (CI-overlap) |
|---|---|---|---|---|---|---|---|---|---|
| 5 | 0.35 | 0.9 | 0.5 | 0.625 | 0.3356 | 0.1526 | 75 | 0.750 | 0.625 |
| 5 | 0.35 | 0.9 | 0.5 | 0.625 | 0.3356 | 0.1526 | 150 | 1.000 | 0.975 |
| 5 | 0.35 | 0.9 | 0.5 | 0.625 | 0.3356 | 0.1526 | 300 | 1.000 | 1.000 |

## 3d. Cỡ mẫu cần để đạt MDE mục tiêu (biện minh cho n headline)

| n_trials | n_per_edge | mean MDE | đạt mục tiêu? |
|---|---|---|---|
| 100 | 100 | 0.142 | — |
| 200 | 200 | 0.100 | — |
| 400 | 400 | 0.071 | ✅ |
| 800 | 800 | 0.051 | ✅ |
| 1600 | 1600 | 0.036 | ✅ |

## 4. R0 vs d*s_bar calibration (engine natural runs, metric.md §5)

| topology | n | p | s_bar | d | d*s_bar | R0 | rel_err |
|---|---|---|---|---|---|---|---|
| chain | 7 | 0.3 | 0.304 | 0.857 | 0.261 | 0.338 | 0.295 |
| chain | 7 | 0.6 | 0.600 | 0.857 | 0.514 | 0.601 | 0.169 |
| chain | 7 | 0.9 | 0.899 | 0.857 | 0.770 | 0.813 | 0.055 |
| chain | 7 | 1.0 | 1.000 | 0.857 | 0.857 | 0.857 | 0.000 |
| star | 7 | 0.3 | 0.337 | 0.857 | 0.289 | 0.250 | 0.136 |
| star | 7 | 0.6 | 0.611 | 0.857 | 0.524 | 0.387 | 0.261 |
| star | 7 | 0.9 | 0.893 | 0.857 | 0.765 | 0.474 | 0.381 |
| star | 7 | 1.0 | 1.000 | 0.857 | 0.857 | 0.500 | 0.417 |
| tree | 7 | 0.3 | 0.306 | 0.857 | 0.262 | 0.517 | 0.972 |
| tree | 7 | 0.6 | 0.621 | 0.857 | 0.532 | 0.735 | 0.381 |
| tree | 7 | 0.9 | 0.897 | 0.857 | 0.769 | 0.838 | 0.089 |
| tree | 7 | 1.0 | 1.000 | 0.857 | 0.857 | 0.857 | 0.000 |

## 5. Recommended N per edge / trials (Wilson half-width at p = 0.5)

| half-width | z | N recommended (p=0.5) |
|---|---|---|
| 0.1 | 1.96 | 97 |
| 0.05 | 1.96 | 385 |
| 0.03 | 1.96 | 1068 |

## 6. Diễn giải (kết luận cho thiết kế experiment)

- **Wilson CI**: coverage dao động quanh 0.95 (0.92–0.97) khắp grid p/n —
  đúng nominal level; n=30 (floor của metric.md §1) vẫn đạt coverage ≈ 0.95 với
  half-width ~0.17–0.33 (p gần 0.5), đủ cho so sánh tương đối nhưng rộng cho
  claim tuyệt đối. Muốn half-width ≤ 0.05 tại p=0.5 cần N ≈ 385 trial/edge.
- **Markov test size**: với dữ liệu Markov thật, tỷ lệ reject (sub+super) chỉ
  ~0.3–1.0% — quy tắc CI-overlap bảo thủ (conservative) so với mức 5% danh nghĩa:
  không tạo false alarm đáng kể. Khi báo cáo verdict cần nói rõ đây là kiểm định
  bảo thủ (không phải p-value 5%).
- **Markov test power**: với hiệu ứng latent-regime mạnh (s_lo=0.4, s_hi=0.9),
  power tăng theo cỡ mẫu: 0.66 (trials=100) → 0.94 (200) → 0.99 (300). Nên dùng
  trials ≥ 200–300 khi muốn phát hiện super-/sub-Markov deviation cỡ trung bình.
- **R0 vs d·s̄**: đúng (rel_err → 0) khi p → 1 trên chain/tree (topology đều).
  Với p < 1, R0 lệch d·s̄ (rel_err 5–30%+) vì |I| chỉ gồm instance compromised —
  d·s̄ chỉ là xấp xỉ cho vùng bão hoà, KHÔNG phải đẳng thức. Star fan-in lệch cấu
  trúc (R0 → 0.5 tại p=1 ≠ d·s̄=0.857) vì center không có downstream — cần diễn
  giải riêng (xem ghi chú configs/star_static_colluding.yaml).
