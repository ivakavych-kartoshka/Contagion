# Scale / Cost Plan cho Real-LLM Sweep (dựa trên pilot v2 thực tế)

## 1. Chi phí thực đo được (qwen2.5:7b local, GPU 4GB, pilot v2: trials=10, per_edge=15)

| Cell | elapsed thực | note |
|---|---|---|
| chain·none | 1401.5s (~23 min) | |
| chain·paraphrase | 1430.3s (~24 min) | |
| star·none | 1334.6s (~22 min) | |
| tree·none | 2345.3s (~39 min) | 6 edges × 15 per-edge + sâu |
| **4 cells (nối tiếp)** | **~6500s ≈ 1.8h** | |

## 2. Call budget ước lượng cho 1 cell (chain n=5)

- natural runs: ~5 calls/trial (entry compromised + ≤4 downstream steps) × trials
- per-edge: n_edges × (1 compromised-output + per_edge_trials dst steps)
- MR y^direct: ~#roles distinct (≤5) — cache theo (client, system)

Công thức: `calls ≈ trials·5 + n_edges·(1+per_edge) + 5`

| trials | per_edge | calls (chain n=5) | calls (tree n=7) |
|---|---|---|---|
| 10 | 15 | ~130 | ~230 |
| 100 | 30 | ~650 | ~1250 |
| 200 | 50 | ~1270 | ~2450 |
| 300 | 100 | ~2050 | ~4200 |

## 3. Thời gian thực tế (hiệu chỉnh từ v2: ~10.5s/call trung bình có load/retry/output dài)

| Config | calls | 7b thực tế (10.5s/call) | 3b ước tính (~5s/call) | API (giả định 1.5s/call) |
|---|---|---|---|---|
| pilot 1 cell (10/15) | ~130 | ~23 min ✓ (đo thật) | ~11 min | ~3 min |
| **1 cell Markov power (200/50)** | ~1270 | **~3.7 h** | ~1.8 h | ~32 min |
| **1 cell headline (300/100)** | ~2050 | ~6 h | ~2.9 h | ~51 min |
| **Full matrix 3 topo × 2 defense (200/50)** | ~3×2×1270 ≈ 7600 | **~22 h** | ~10.5 h | ~3.2 h |

## 4. Kết luận / khuyến nghị

- **7b local**: pilot-level (trials 10-30) khả thi; Markov power (trials 200-300)
  cho full matrix = **~22h** — quá lâu cho iteration nhanh nhưng chạy qua đêm được.
- **3b local**: nhanh ~2× nhưng là model KHÁC → **judge cần calibrate lại** (ngưỡng
  ASV/MR per-model) trước khi dùng số liệu.
- **API mạnh (GPT/DeepSeek...)**: full matrix ~3h — hợp lý cho paper; cần budget
  (chi phí đô-la) + re-calibrate judge + khả năng compliance khác hẳn qwen local.
- **Chưa nên sweep lớn ngay**: pilot v2 phát hiện judge ASV τ=0.9 false-negative
  cao trên propagation thật (chain·none ASR=0) — phải giải quyết judge trước, nếu
  không toàn bộ sweep tốn chi phí vào số liệu lệch.

## 5. Khuyến nghị trước mắt (theo thứ tự)

1. Probe phân phối ASV propagation không-gate → chọn τ_asv đúng cho propagation
   (không phải cho probe nhân tạo retry-gate).
2. Fix judge (τ/định nghĩa relay-intent) + chạy lại pilot 1-2 cells xác nhận.
3. Mới quyết định sweep scale theo bảng trên.
