# Subset đã chọn (0 call model)

- nguồn: `experiments\results\validation_qwen_mini\transcript.jsonl` — 24 dòng judged
- chọn: **24 mẫu** (seed=7, trần 8/tầng)

## Phân bố

| chiều | phân bố |
|---|---|
| defense | none: 24 |
| arm | canonical: 6, hardcoded: 6, in_context: 6, sender_ctx: 6 |
| role | aggregator: 8, reviewer: 8, worker: 8 |
| payload | BANANA-77: 24 |
| judge dương (ASV≥τ hoặc MR≥τ) | 19/24 |
| judge ASV≥0.9 | 19/24 |
| mã nguyên vẹn trong output | 19/24 |

→ Đây là subset thoả yêu cầu "phân bố đều qua điều kiện" của R2 (no-defense/defense, đúng/sai theo judge, nhiều hình thức/arm, role).

## Bước tiếp theo

1. Gán nhãn `labels_to_fill.csv` → lưu `labels_filled.csv`.
2. `python scripts\score_validation_subset.py --dir experiments\results\validation_qwen_mini --labels labels_filled.csv`

