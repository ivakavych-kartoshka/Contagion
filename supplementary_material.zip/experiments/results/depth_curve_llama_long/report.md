# Depth curve — bedrock · us.meta.llama3-3-70b-instruct-v1:0

chain n=15 · natural trials=120 · per-edge=60 · temp=0.7 · **fresh-artefact** (bắt buộc cho claim compositional)

Mỗi node là MỘT mốc độ sâu. `P(C_i=1)` đo từ natural runs; `∏s^cách ly` là tích các `s` đo cách ly trên đường từ entry tới node đó.

| depth i | agent | s cách ly vào node | P(C_i=1) đo được | ∏s cách ly | sai số tương đối |
|---|---|---|---|---|---|
| 0 | `agent_0` | — | 1.000 [0.969, 1.000] | 1.0000 | **0.0%** |
| 1 | `agent_1` | 1.000 | 1.000 [0.969, 1.000] | 1.0000 | **0.0%** |
| 2 | `agent_2` | 0.283 | 0.908 [0.843, 0.948] | 0.2833 | **68.8%** |
| 3 | `agent_3` | 1.000 | 0.867 [0.794, 0.916] | 0.2833 | **67.3%** |
| 4 | `agent_4` | 1.000 | 0.642 [0.553, 0.722] | 0.2833 | **55.8%** |
| 5 | `agent_5` | 1.000 | 0.583 [0.494, 0.668] | 0.2833 | **51.4%** |
| 6 | `agent_6` | 0.300 | 0.542 [0.453, 0.628] | 0.0850 | **84.3%** |
| 7 | `agent_7` | 1.000 | 0.508 [0.420, 0.596] | 0.0850 | **83.3%** |
| 8 | `agent_8` | 1.000 | 0.408 [0.325, 0.498] | 0.0850 | **79.2%** |
| 9 | `agent_9` | 1.000 | 0.367 [0.286, 0.456] | 0.0850 | **76.8%** |
| 10 | `agent_10` | 0.383 | 0.342 [0.263, 0.430] | 0.0326 | **90.5%** |
| 11 | `agent_11` | 1.000 | 0.000 [0.000, 0.031] | 0.0326 | **—** |
| 12 | `agent_12` | 1.000 | 0.000 [0.000, 0.031] | 0.0326 | **—** |
| 13 | `agent_13` | 1.000 | 0.000 [0.000, 0.031] | 0.0326 | **—** |
| 14 | `agent_14` | 0.317 | 0.000 [0.000, 0.031] | 0.0103 | **—** |

## Cách đọc

- **Cột cuối là claim trung tâm**: sai số tương đối của phép đo cách ly theo độ sâu. Kỳ vọng: tăng theo `i`.
- Ở độ sâu lớn, `P(C_i=1)` tiến về 0 và CI rất rộng ⇒ các điểm cuối **kém tin cậy**; phải đọc kèm CI, và cần `--trials` đủ lớn.
- Model đáng tin cho đường cong này là model có `s` trung bình cao (nếu `s̄ ≈ 0.7`, chuỗi 14 hop gần như tắt hẳn).
